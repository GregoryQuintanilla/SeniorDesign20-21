This folder contains information relevent to the development of our Chrome browser Extension

## Links to Materials
https://developer.chrome.com/docs/extensions/mv2/getstarted/
- This link above is for the a very basic browser extension and gives some knowledge into the flow and components of an extension
such as the background, popup, options, and a projects manifest. Additional information can be found inrowser  L