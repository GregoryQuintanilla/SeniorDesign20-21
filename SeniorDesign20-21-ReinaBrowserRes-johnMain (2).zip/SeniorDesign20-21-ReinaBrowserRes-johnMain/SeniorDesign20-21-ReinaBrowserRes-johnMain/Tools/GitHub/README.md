This folder contains any information related to learning github so that our configuration management can hopefully run smoother. 

## Links to Materials
https://docs.github.com/en/free-pro-team@latest/github/writing-on-github/basic-writing-and-formatting-syntax

- This link is on how to write these readmes so they look a little bit better and how the formatting works. Pretty minor but is something to consider.