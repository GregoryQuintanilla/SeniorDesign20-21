This folder contains information relevant to the development of anything realting to Google Firebase, such as hosting, firestore and any other materials we end up using. 

## Links to Materials